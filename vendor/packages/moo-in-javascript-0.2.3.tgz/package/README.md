# moo-in-javascript

A standalone JavaScript interpreter for a documented subset of MOO,
usable from Node.js and browsers. It executes verb bodies against a small
in-memory world and return real values, output, state changes, and diagnostics.

**Status:** v0.2 implemented. Expressions, collections, control flow,
scatter and error handling execute with typed results and deterministic limits.
Retained worlds, inherited verb calls, object programming and live output work.
Versioned JSON snapshots, atomic load, Reset and host verb registrations work.
Browser/Node workers support live output, Stop, timeouts and transactional commits.
Reviewed corpus execution and separate academy integration are validated.
This repository is independent of `~/moo-academy`. Implementation uses
TypeScript compiled to JavaScript ESM, with type declarations for consumers.

See [PLAN.md](PLAN.md) for scope, architecture, dependencies, milestones, testing,
and the package integration contract.

See [development](docs/development.md), [compatibility](docs/compatibility.md),
and [implementation progress](docs/progress.md) for validation evidence.
See [worlds](docs/worlds.md) for object APIs and output contracts.
See [snapshots](docs/snapshots.md) for save/load, sessions and host registrations.
See [workers](docs/workers.md) for isolated execution, Stop and commit behavior.
See [corpus evidence](docs/corpus.md) for independently reviewed execution cases.

```js
import { createRuntime } from 'moo-in-javascript';
const runtime = await createRuntime({ profile: 'toaststunt' });
try {
  console.log(runtime.run('return 1 + 2;'));
} finally {
  runtime.dispose();
}
```

## Supported scope

Support explicit LambdaMOO and ToastStunt profiles, broad beginner syntax,
ToastStunt maps, inherited/programmatically editable objects, persistent worlds,
and JSON snapshots. Provide live output and Stop through a browser Worker, with
Node.js support and no required MOO server. Profile selection is explicit.

Ordinary runtime errors and controlled limits preserve prior world changes.
Forced Stop discards that run's changes; output already delivered remains visible.
Snapshots save world data, MOO source, and profile, without editor/session state.

All six academy lessons are an early integration check, not the whole scope.
Normal tests use reviewed expectations; optional development checks can use the
user's existing dev MOO through MCP. Permissions are deliberately not enforced.

## Upstream projects

- [tree-sitter-moo](https://github.com/SindomeCorp/tree-sitter-moo): grammar and WASM parser.
- [moo-for-llms](https://github.com/SindomeCorp/moo-for-llms): development/test corpus and reference material.

The corpus is a development dependency; it will not be shipped to browsers.
Dependency revisions and provenance requirements are specified in the plan.

## License

[MIT](LICENSE). Upstream dependency notices will be retained with packaged assets.

Builtin signatures and return behavior are discoverable through the JavaScript
catalog and MOO `function_info()`; see [introspection](docs/builtin-introspection.md).


## Test coverage

```sh
npm test                 # Build and run the Node suite
npm run test:coverage    # Same suite, with enforced coverage and an LCOV report
npm run test:browser     # Chromium runtime and worker checks
npm run test:package     # Clean Node, TypeScript, and browser package consumers
```

`test:coverage` writes `coverage/lcov.info` and prints a per-module summary.
The Node 22 CI job enforces at least **95% line, 90% branch, and 95% function**
coverage and uploads LCOV even when the test step fails. Measurements cover the
unbundled runtime JavaScript loaded by Node, including Node execution workers;
they exclude duplicate browser bundles and generated assets. Browser and clean
package checks run separately and are not included in those percentages.

The suite covers both supported profiles using independently authored semantic
expectations. Named cases exercise worker protocol failures and transaction
recovery, exact builtin results and effects, rejected metadata edits, world quotas,
arithmetic boundaries, control flow, and host API validation. Generic snapshot and
metadata tests use a small test-owned world; only teaching integration tests rely
on the classroom hierarchy. The 447-file grammar baseline tests syntax, while the
reviewed execution corpus checks 17 programs. Neither is live-server differential
conformance testing.

Coverage thresholds are a floor, not a substitute for assertions about results,
output, world state, and recovery after errors. A worker-message regression also
verifies that null or malformed messages reject with `WorkerHostError`, preserve
committed state and delivered output, and release the world for the next run.

Expanded builtins include a persistent educational host and bounded SQLite. See
[host simulation](docs/host-simulation.md) and [coverage/remaining work](docs/builtin-roadmap.md).

This product includes software developed or owned by Caldera International, Inc.
See [third-party notices](docs/third-party-notices.md).
